import React from "react";
import { motion } from "framer-motion";

export default function Home() {
  return (
    <div className="bg-red-500 min-h-screen text-white text-center p-6">
      <motion.img 
        src="/MiXue-logo.png" 
        alt="$MIXUE Logo" 
        className="mx-auto w-40 h-40"
        initial={{ scale: 0.8 }}
        animate={{ scale: 1 }}
        transition={{ duration: 0.5 }}
      />
      <h1 className="text-4xl font-bold mt-4">$MIXUE - 币圈最甜的财富风暴来袭！</h1>
      <p className="mt-2">🎵 你爱我，我爱你，$蜜雪冰城甜蜜密！ 🎵</p>

      <div className="mt-8">
        <h2 className="text-2xl font-bold">如何购买？</h2>
        <p className="mt-2">在 PancakeSwap 购买 $MIXUE：</p>
        <a href="https://pancakeswap.finance/?inputCurrency=0x315eFBeD2FFd6c5823C72bd303384A87dD6a546E&outputCurrency=BNB" target="_blank" rel="noopener noreferrer">
          <button className="mt-4 bg-yellow-400 text-red-700 text-lg px-4 py-2 rounded-lg">
            立即购买
          </button>
        </a>
      </div>

      <div className="mt-8">
        <h2 className="text-2xl font-bold">合约地址</h2>
        <p className="mt-2 text-lg font-mono bg-gray-800 p-2 rounded-lg inline-block">
          0x315eFBeD2FFd6c5823C72bd303384A87dD6a546E
        </p>
      </div>

      <footer className="mt-16">
        <p>💬 加入我们的 Telegram 群组: <a href="https://t.me/MIXUE998" className="text-blue-300">点击加入</a></p>
      </footer>
    </div>
  );
}